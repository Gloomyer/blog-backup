#include "com_gloomyer_ffmepgplay_VideoUtils.h"
#include "include/ffmpeg/libavcodec/avcodec.h"
#include "include/ffmpeg/libavformat/avformat.h"
#include "include/ffmpeg/libswscale/swscale.h"
#include "include/libyuv/libyuv.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>

#define LOGI(FORMAT, ...) __android_log_print(ANDROID_LOG_INFO,"TAG",FORMAT,##__VA_ARGS__);
#define LOGE(FORMAT, ...) __android_log_print(ANDROID_LOG_ERROR,"TAG",FORMAT,##__VA_ARGS__);

JNIEXPORT void JNICALL Java_com_gloomyer_ffmepgplay_VideoUtils_decode
        (JNIEnv *env, jclass jcls, jstring input_jstr, jstring output_jstr) {

    //需要转码的视频文件(输入的视频文件)
    const char *input_cstr = (*env)->GetStringUTFChars(env, input_jstr, NULL);
    const char *output_cstr = (*env)->GetStringUTFChars(env, output_jstr, NULL);

    av_register_all();//注册

    AVFormatContext *pFormatCtx;

    avformat_open_input(&pFormatCtx, input_cstr, NULL, NULL);

    avformat_find_stream_info(pFormatCtx, NULL);

    int index;
    for (int i = 0; i < pFormatCtx->nb_streams; i++) {
        if (pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            index = i;
            break;
        }
    }

    AVCodecContext *pCodecCtx = pFormatCtx->streams[index]->codec;
    AVCodec *pCodec = avcodec_find_decoder(pCodecCtx->codec_id);


    if (avcodec_open2(pCodecCtx, pCodec, NULL) < 0) {
        LOGE("%s", "解码器无法打开");
        return;
    }

    AVPacket *pPacket = (AVPacket *) av_malloc(sizeof(AVPacket));

    //像素数据（解码数据）
    AVFrame *pFrame = av_frame_alloc();
    AVFrame *pFrameYUV = av_frame_alloc();

    uint8_t *out_buffer = (uint8_t *)
            av_malloc(avpicture_get_size(AV_PIX_FMT_YUV420P, pCodecCtx->width, pCodecCtx->height));

    avpicture_fill((AVPicture *) pFrameYUV,
                   out_buffer, AV_PIX_FMT_YUV420P, pCodecCtx->width, pCodecCtx->height);

    FILE *fp_yuv = fopen(output_cstr, "wb");
    int frame_count = 0;

    struct SwsContext *sws_ctx = sws_getContext(
            pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt,
            pCodecCtx->width, pCodecCtx->height, AV_PIX_FMT_YUV420P,
            SWS_BILINEAR, NULL, NULL, NULL);

    int len, got_frame, framecount = 0;

    while (av_read_frame(pFormatCtx, pPacket) >= 0) {
        len = avcodec_decode_video2(pCodecCtx, pFrame, &got_frame, pPacket);
        if (got_frame) {
            sws_scale(sws_ctx,
                      pFrame->data, pFrame->linesize, 0, pFrame->height,
                      pFrameYUV->data, pFrameYUV->linesize);

            int y_size = pCodecCtx->width * pCodecCtx->height;
            fwrite(pFrameYUV->data[0], 1, y_size, fp_yuv);
            fwrite(pFrameYUV->data[1], 1, y_size / 4, fp_yuv);
            fwrite(pFrameYUV->data[2], 1, y_size / 4, fp_yuv);

            LOGI("解码%d帧", framecount++);
        }
        av_free_packet(pPacket);
    }

    fclose(fp_yuv);
    av_frame_free(&pFrame);
    av_frame_free(&pFrameYUV);
    avcodec_close(pCodecCtx);
    avformat_free_context(pFormatCtx);
    (*env)->ReleaseStringUTFChars(env, input_jstr, input_cstr);
    (*env)->ReleaseStringUTFChars(env, output_jstr, output_cstr);
}


JNIEXPORT void JNICALL Java_com_gloomyer_ffmepgplay_VideoUtils_render
        (JNIEnv *env, jclass jcls, jstring input_jstr, jobject suface_jobj) {
    const char *input_cstr = (*env)->GetStringUTFChars(env, input_jstr, NULL);
    LOGE("%s", "开始执行jni代码");
    av_register_all();//注册
    LOGE("%s", "注册组件成功");
    AVFormatContext *pFormatCtx = avformat_alloc_context();
    LOGE("%s", "注册变量");
    //2.打开输入视频文件
    if (avformat_open_input(&pFormatCtx, input_cstr, NULL, NULL) != 0) {
        LOGE("%s", "打开输入视频文件失败");
        return;
    } else {
        LOGE("%s", "打开视频文件成功!");
    }

    //3.获取视频信息
    if (avformat_find_stream_info(pFormatCtx, NULL) < 0) {
        LOGE("%s", "获取视频信息失败");
        return;
    } else {
        LOGE("%s", "获取视频信息成功！");
    }

    int index;
    for (int i = 0; i < pFormatCtx->nb_streams; i++) {
        if (pFormatCtx->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            index = i;
            break;
        }
    }

    //4.获取视频解码器
    AVCodecContext *pCodecCtx = pFormatCtx->streams[index]->codec;
    AVCodec *pCodec = avcodec_find_decoder(pCodecCtx->codec_id);

    if (pCodec == NULL) {
        LOGE("%s", "无法解码");
        return;
    } else {
        LOGE("%s", "可以正常解码");
    }

    //5.打开解码器
    if (avcodec_open2(pCodecCtx, pCodec, NULL) < 0) {
        LOGE("%s", "解码器无法打开");
        return;
    } else {
        LOGE("%s", "解码器打开成功!");
    }

    //编码数据
    AVPacket *pPacket = (AVPacket *) av_malloc(sizeof(AVPacket));

    //像素数据（解码数据）
    AVFrame *pYuvFrame = av_frame_alloc();
    AVFrame *pRgbFrame = av_frame_alloc();

    //native绘制
    //窗体
    ANativeWindow *pNativeWindow = ANativeWindow_fromSurface(env, suface_jobj);
    //绘制时的缓冲区
    ANativeWindow_Buffer outBuffer;
    //6.一阵一阵读取压缩的视频数据AVPacket
    int len, got_frame, framecount = 0;
    LOGE("%s", "开始一帧一帧解码");
    while (av_read_frame(pFormatCtx, pPacket) >= 0) {
        //解码AVPacket->AVFrame
        len = avcodec_decode_video2(pCodecCtx, pYuvFrame, &got_frame, pPacket);
        LOGE("%s len=%d got_frame=%d", "尝试解码", len, got_frame);
        if (got_frame) {
            LOGI("解码%d帧", framecount++);
            //设置缓冲区的属性（宽、高、像素格式）
            ANativeWindow_setBuffersGeometry(pNativeWindow,
                                             pCodecCtx->width,
                                             pCodecCtx->height,
                                             WINDOW_FORMAT_RGBA_8888);
            //lock
            ANativeWindow_lock(pNativeWindow, &outBuffer, NULL);

            //设置rgb_frame的属性（像素格式、宽高）和缓冲区
            //rgb_frame缓冲区与outBuffer.bits是同一块内存
            avpicture_fill((AVPicture *) pRgbFrame,
                           outBuffer.bits,
                           PIX_FMT_RGBA,
                           pCodecCtx->width,
                           pCodecCtx->height);


            I420ToARGB(pYuvFrame->data[0], pYuvFrame->linesize[0],
                       pYuvFrame->data[2], pYuvFrame->linesize[2],
                       pYuvFrame->data[1], pYuvFrame->linesize[1],
                       pRgbFrame->data[0], pRgbFrame->linesize[0],
                       pCodecCtx->width, pCodecCtx->height);

            ANativeWindow_unlockAndPost(pNativeWindow);

            usleep(1000 * 16);
        }
        av_free_packet(pPacket);
    }

    av_frame_free(&pYuvFrame);
    av_frame_free(&pRgbFrame);
    avcodec_close(pCodecCtx);
    avformat_free_context(pFormatCtx);
    ANativeWindow_release(pNativeWindow);
    (*env)->ReleaseStringUTFChars(env, input_jstr, input_cstr);
}
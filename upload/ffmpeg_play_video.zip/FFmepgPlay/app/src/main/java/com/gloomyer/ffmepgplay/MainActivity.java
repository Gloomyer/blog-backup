package com.gloomyer.ffmepgplay;

import android.graphics.PixelFormat;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    SurfaceView mSurfaceView;
    private SurfaceHolder mHolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSurfaceView = (SurfaceView) findViewById(R.id.mSurfaceView);
        init();
    }

    private void init() {
        mHolder = mSurfaceView.getHolder();
        mHolder.setFormat(PixelFormat.RGBA_8888);
    }

    public void play(View v) {
        final String input = new File(Environment.getExternalStorageDirectory(), "input.mp4").getAbsolutePath();
        new Thread() {
            @Override
            public void run() {
                VideoUtils.render(input, mHolder.getSurface());
            }
        }.start();
    }
}
